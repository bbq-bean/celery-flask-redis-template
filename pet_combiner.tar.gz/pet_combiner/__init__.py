#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
Initialization module for this API. Sets version
"""

__version__ = "0.1.0"